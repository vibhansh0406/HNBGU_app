# CAMPUSONE — ONE-DAY AUTONOMOUS PRODUCT TRANSFORMATION
## OpenCode + AndCode + NVIDIA Nemotron 3.5 Super VL

You are the senior Android engineer, product designer, design-system architect, QA engineer, and release reviewer for CampusOne.

Your assignment is to transform the EXISTING CampusOne application into a cohesive, premium, expressive, reliable student product. This is a real application overhaul, not a mockup exercise.

The user is running OpenCode inside AndCode and intends to use an NVIDIA Nemotron 3.5 Super VL model. Work only with tools and capabilities actually available in the current environment. Do not assume emulator, browser, screenshot, shell, GitHub, or filesystem access unless verified.

## NON-NEGOTIABLE PRODUCT GOALS

1. Premium, distinctive educational product; not generic template UI.
2. Brand tagline: "Your campus. One place."
3. White-first launch experience.
4. Light theme, dark theme, and system theme.
5. Silent cinematic/hybrid logo reveal.
6. Preserve the exact uploaded C logo geometry. Do not redesign, reshape, rotate, crop, or embellish the symbol.
7. Improve actual working functionality and data correctness, not just visuals.
8. Preserve all existing working features and backend contracts unless a verified defect requires a carefully documented fix.
9. No fake production data, fake success states, or mock API fallbacks disguised as real data.
10. No destructive production database changes.

## INPUT ASSETS

The supplied package contains:
- `brand-assets/original-uploaded-C-logo-reference.png` — original user-supplied raster logo reference.
- `brand-assets/campusone-c-mark.svg` — traced transparent vector draft of the C mark.
- `brand-assets/campusone-app-icon.svg` — white rounded-square icon composition.
- `brand-assets/README.txt` — asset limitations and usage notes.

IMPORTANT: The SVG files are vector traces from the supplied raster reference, not the original editable vector master. Compare them visually against the original reference before release. If any contour differs, preserve the original reference as source of truth and report the discrepancy. Do not claim pixel-perfect identity without verification. Keep the SVG master files in the repository. Android may require VectorDrawable XML or rasterized density assets; do not assume Android can load SVG directly as a normal drawable.

## EXECUTION RULES

- First inspect the repository and determine the actual stack, architecture, build system, navigation, data layer, Supabase integration, authentication, role model, local cache, and existing tests.
- Do not infer the architecture from this prompt.
- Before edits, record the current Git branch/status and establish a safe checkpoint if Git is available.
- Never overwrite user changes or discard uncommitted work. If the worktree is dirty, inspect and preserve those changes.
- Create a dedicated feature branch only if Git is available and safe to do so.
- Work in small, reviewable phases. Commit/checkpoint each completed phase if Git is available.
- Maintain `CAMPUSONE_PROGRESS.md` at the repository root with completed work, current phase, changed files, tests, blockers, and next steps.
- Do not repeatedly rescan unchanged files. Maintain a concise project map.
- Do not claim a test, screenshot review, build, deployment, or backend verification happened unless it actually happened.
- If a tool/capability is unavailable, continue with tasks that can be safely completed and clearly report the limitation.
- If context or session limits approach, save state in `CAMPUSONE_PROGRESS.md` and leave precise next steps.
- Do not chase token consumption. Optimize for verified product quality.

## PHASE 0 — REPOSITORY AND BASELINE AUDIT

1. Inspect project structure and identify:
   - Android framework and language.
   - Compose/XML/UI architecture.
   - Entry points and navigation graph.
   - All screens and reusable components.
   - Theme, typography, color and dimension definitions.
   - Supabase client initialization and environment configuration.
   - Authentication/session handling.
   - Student/admin role resolution and authorization.
   - Tables and queries used by the app.
   - Local persistence/cache and sync strategy.
   - Download/file handling.
   - Build variants and signing configuration (do not expose secrets).
   - Existing unit/UI tests.
2. Run the existing build/test baseline if available.
3. Record failures that existed before your changes.
4. Identify hardcoded demo data, placeholder content, mock repositories, static counts, fake announcements, and fake resource lists.
5. Produce a concise audit before major edits.

## PHASE 1 — DATA AND BACKEND TRUTHFULNESS

The user previously reported that the Super Admin screen showed only two users even after several friends installed the app. Supabase Auth showed multiple accounts, while `public.profiles` and `public.students` appeared to contain fewer records, and `study_resources` was empty.

Investigate this as a real data-flow problem. Do not assume Supabase is down.

Verify, without exposing secrets:
- Which Supabase project URL and anon/publishable key the app is configured to use.
- Whether the installed APK points to the intended production project/environment.
- Whether signup/login creates an Auth user.
- Whether a profile row is created for each new Auth user.
- Whether a student row is expected, and whether it is created.
- Whether profile/student inserts fail due to RLS, triggers, constraints, missing fields, or swallowed exceptions.
- Whether the Super Admin user count queries `auth.users`, `public.profiles`, or `public.students`.
- Whether RLS prevents the admin query from seeing all intended records.
- Whether the admin dashboard uses hardcoded sample counts or cached stale values.
- Whether pagination, filters, duplicate IDs, or role filters exclude users.
- Whether the app is connected to a different Supabase project than the dashboard screenshot.
- Whether announcements/resources are genuinely empty in the database or merely failing to load.

Important Supabase constraints:
- The client-side anon/publishable key is not a service-role key.
- Never put a service-role key in the Android app.
- Never disable RLS to make the dashboard appear populated.
- Never bypass authorization by trusting a client-supplied `is_admin` flag.
- Use secure database policies or server-side/Edge Function logic for privileged admin operations.
- Do not query `auth.users` directly from an ordinary client if the platform/security model does not permit it.
- Use the existing secure architecture where possible.
- Never create fake student/profile/resource rows to inflate counts.
- Do not run destructive SQL or production migrations without explicit approval.

If the defect cannot be fixed safely from repository code alone, produce the exact minimal SQL/migration or Supabase dashboard action needed, explain the risk, and stop before applying destructive or privileged changes.

## PHASE 2 — DESIGN SYSTEM

Create a centralized, reusable design system. Avoid scattered one-off colors and dimensions.

Brand direction:
- Premium minimal.
- Midnight navy identity.
- White-first visual language.
- Controlled expressive accent colors.
- Strong typographic hierarchy.
- Friendly, motivating student experience without childish/cartoon styling.

Suggested starting tokens (adapt to existing design conventions and validate contrast):

LIGHT:
- Background: #FFFFFF
- Surface: #F5F6F8
- Elevated surface: #FFFFFF
- Primary text: #080B19
- Secondary text: #667085
- Brand accent: #4263EB
- Border: #E6E8ED

DARK:
- Background: #080B19
- Surface: #111827
- Elevated surface: #182235
- Primary text: #F8FAFC
- Secondary text: #A1AABD
- Brand accent: #7890FF
- Border: #263247

Semantic colors:
- Success: green.
- Warning/pending: amber.
- Destructive/logout/delete: red.
- Information/links: blue.
- Neutral actions: neutral surfaces.

Use Manrope for brand/display typography and Inter for UI only if the fonts can be added legally and reliably. Otherwise choose suitable fonts already available in the project and document the decision.

Create tokens for:
- Typography scale and weights.
- Spacing.
- Corner radii.
- Elevation.
- Icon sizes.
- Touch targets.
- Button heights.
- Card padding.
- Motion duration/easing.
- Light/dark semantic colors.

## PHASE 3 — BUTTON AND COMPONENT HIERARCHY

Replace the current same-looking buttons with semantic variants:
- Primary: main save/continue/submit action.
- Success: download/completed/positive action.
- Warning: pending/attention-required.
- Destructive: logout/delete/irreversible action.
- Secondary: supporting action.
- Outlined: edit/alternative action.
- Text: low-emphasis action.

Rules:
- Do not make every button a different arbitrary color.
- Color must communicate action meaning.
- Minimum touch target around 48dp where practical.
- Flexible width and wrapping; do not truncate labels unnecessarily.
- Icons and labels must align.
- Clear pressed, disabled, loading, focused and error states.
- Accessible contrast in both themes.
- No tiny text inside undersized buttons.

Audit every screen and migrate to shared components.

## PHASE 4 — HUB REDESIGN

Make Hub a polished campus resource centre, not a generic list of identical buttons.

Suggested categories and accents:
- Study materials: blue.
- Notes: violet.
- Assignments: orange.
- Previous papers: teal.
- Syllabus: indigo.
- Timetable: cyan.
- Results: green.
- Announcements: amber.

Each category should have:
- Meaningful icon.
- Clear title.
- Short description where useful.
- Consistent card structure.
- Semantic accent.
- Consistent spacing and responsive dimensions.
- Clear interaction/tap target.

Use visual variety through hierarchy, layout, iconography and accents—not random styling.

## PHASE 5 — NOTES AND LEARNING EXPERIENCE

Notes discovery:
- Subject/chapter grouping.
- Search and filters.
- Recently opened.
- Bookmarks/favourites.
- Download status.
- Clear empty and error states.

Reading screen:
- Comfortable font size and line height.
- Proper margins.
- Clear headings.
- Reading progress where supported.
- Bookmark/share actions.
- Dark reading mode.
- Avoid cramped content.

Resource details:
- File name/type/size.
- Subject/chapter.
- Upload date if stored.
- Download action.
- Related resources if supported by actual data.

PDF viewer:
- Inspect the existing implementation.
- Improve usability without breaking loading, pagination, zoom, downloads, or file access.
- Do not invent metadata that is not in the database.

## PHASE 6 — ALL OTHER SCREENS

Audit and refine:
- Student home/dashboard.
- Attendance and attendance logs.
- Announcements and notice reads.
- Timetable.
- Exams/results/GPA where implemented.
- Profile/settings.
- Admin dashboard.
- User/role management.
- Clubs, campus map, directory, lost & found, and other existing modules.

Preserve existing features. Do not remove a screen because it is difficult to redesign.

## PHASE 7 — RESPONSIVE LAYOUT AND TYPOGRAPHY

Test common Android phone sizes, larger phones and tablets where tooling permits.

Fix:
- Overlapping components.
- Bottom navigation misalignment.
- Clipped/truncated labels.
- Horizontal overflow.
- Fixed-width assumptions.
- Inconsistent card heights.
- Bad baseline alignment.
- Excessive whitespace.
- Incorrect scrolling.
- Poor font scaling.

Suggested starting type scale:
- Main screen title: 24–28sp.
- Section title: 18–20sp.
- Card title: 16sp.
- Body: 14–16sp.
- Supporting text: 12–13sp.
- Button: 14–16sp.

Adapt to actual layout; do not force these sizes if they harm accessibility or hierarchy. Respect system font scaling.

## PHASE 8 — BRAND ASSETS, ICON AND SILENT INTRO

Use the supplied C logo assets.

- Preserve original C geometry.
- Keep master SVGs in a clearly named `design/brand/` or equivalent folder.
- Convert to Android-supported resources as required by the actual project.
- Create adaptive launcher icon foreground/background correctly.
- Do not put a pre-rounded full icon into an adaptive foreground if that causes double masking.
- White-first splash screen.
- Silent cinematic/hybrid reveal: geometric reveal, subtle light sweep, wordmark fade-in, tagline appearance, smooth transition.
- No sound/audio.
- Do not add an unnecessarily long startup delay.
- Do not replay the intro on every screen navigation.
- Respect Android's native splash-screen behavior and existing app startup architecture.
- If animation assets/framework are unavailable, implement a lightweight native animation and document it.

Tagline: "Your campus. One place."

## PHASE 9 — MICRO-INTERACTIONS AND ACCESSIBILITY

Add restrained transitions for:
- Tabs.
- Buttons.
- Cards.
- Dialogs.
- Loading skeletons.
- Pull-to-refresh.
- Success/error feedback.
- Empty states.

Respect reduced-motion preferences. Ensure touch targets, content descriptions, keyboard/focus behavior where applicable, and sufficient contrast.

## PHASE 10 — TESTING AND VISUAL QA

Run all available:
- Build tasks.
- Unit tests.
- UI tests.
- Lint/static analysis.
- Navigation regression checks.
- Theme switching checks.
- Authentication checks.
- Data loading/error-state checks.

If screenshots or emulator tools are available, capture and inspect:
- Student home.
- Hub.
- Notes discovery.
- Reading screen.
- Attendance.
- Announcements.
- Profile.
- Admin dashboard.
- Light theme.
- Dark theme.

Fix visual defects discovered. Do not claim visual testing if no screenshots were captured.

Build the final debug/release variant only as appropriate to existing project configuration. Do not change signing secrets or publish/deploy without permission.

## PHASE 11 — FINAL DELIVERY

Update `CAMPUSONE_PROGRESS.md` and produce `CAMPUSONE_FINAL_REPORT.md` containing:

1. Repository architecture summary.
2. Baseline build status.
3. Audit findings.
4. Data/backend investigation findings.
5. Design system changes.
6. Screens/modules changed.
7. Files added/modified.
8. Asset conversion paths.
9. Animation implementation.
10. Build and test commands/results.
11. Screenshots captured (if any).
12. Remaining defects and blockers.
13. Any manual Supabase steps still required, with exact SQL or dashboard navigation only when grounded in inspected schema.
14. Git branch and checkpoint/commit references.
15. Exact APK output path if a build was actually generated.

## DEFINITION OF DONE

The task is complete only when:
- The project builds successfully, or the precise blocker is documented.
- Existing key functionality is preserved.
- No fake production data is introduced.
- Hub and notes experience are materially improved.
- Buttons use semantic variants.
- Typography/alignment/overflow issues are addressed.
- Light and dark themes work.
- The original C logo is preserved as the source of truth.
- Launch is silent and appropriately animated.
- Supabase/data issues are investigated honestly.
- Tests and limitations are reported accurately.

Start with Phase 0. Continue through phases autonomously when safe. Do not stop after a successful compile. Inspect, test, refine, and rebuild.
