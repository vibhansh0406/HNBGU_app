package com.campusone.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.campusone.app.data.local.dao.CoreDao
import com.campusone.app.data.local.dao.StudyAndCampusDao
import com.campusone.app.data.local.entity.AssignmentEntity
import com.campusone.app.data.local.entity.AttendanceRecordEntity
import com.campusone.app.data.local.entity.CourseGradeEntity
import com.campusone.app.data.local.entity.DirectoryContactEntity
import com.campusone.app.data.local.entity.ExamEntity
import com.campusone.app.data.local.entity.PersonalNoticeEntity
import com.campusone.app.data.local.entity.StudyMaterialEntity
import com.campusone.app.data.local.entity.SubjectEntity
import com.campusone.app.data.local.entity.SyllabusTopicEntity
import com.campusone.app.data.local.entity.TimetableSlotEntity

@Database(
    entities = [
        SubjectEntity::class,
        AttendanceRecordEntity::class,
        TimetableSlotEntity::class,
        PersonalNoticeEntity::class,
        AssignmentEntity::class,
        ExamEntity::class,
        SyllabusTopicEntity::class,
        CourseGradeEntity::class,
        StudyMaterialEntity::class,
        DirectoryContactEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class CampusOneDatabase : RoomDatabase() {

    abstract fun coreDao(): CoreDao
    abstract fun studyAndCampusDao(): StudyAndCampusDao

    companion object {
        private const val DB_NAME = "campusone_ondevice.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS directory_contacts (" +
                        "id TEXT NOT NULL, " +
                        "name TEXT NOT NULL, " +
                        "designation TEXT NOT NULL, " +
                        "department TEXT NOT NULL, " +
                        "category TEXT NOT NULL, " +
                        "phone TEXT NOT NULL, " +
                        "email TEXT NOT NULL, " +
                        "officeLocation TEXT NOT NULL, " +
                        "officeHours TEXT NOT NULL, " +
                        "latitude REAL NOT NULL DEFAULT 30.2224, " +
                        "longitude REAL NOT NULL DEFAULT 78.7834, " +
                        "PRIMARY KEY(id))"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_directory_contacts_category_department " +
                        "ON directory_contacts (category, department)"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE subjects ADD COLUMN targetPercentage INTEGER NOT NULL DEFAULT 75"
                )
                db.execSQL(
                    "ALTER TABLE subjects ADD COLUMN colorHex TEXT NOT NULL DEFAULT '#0F4C81'"
                )
                db.execSQL(
                    "ALTER TABLE timetable_slots ADD COLUMN colorHex TEXT NOT NULL DEFAULT '#0F4C81'"
                )
            }
        }

        @Volatile
        private var INSTANCE: CampusOneDatabase? = null

        fun getInstance(context: Context): CampusOneDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CampusOneDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
