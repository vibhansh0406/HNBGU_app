-keepattributes *Annotation*,InnerClasses,Signature
-keep class com.campusone.app.data.local.** { *; }
-keep class com.campusone.app.domain.model.** { *; }
-keep class com.campusone.app.util.CampusBackupPayload { *; }
-dontwarn kotlinx.serialization.**

